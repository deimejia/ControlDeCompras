let numero = parseInt(prompt("Tabla para multiplicar hasta 10"));

for (let i = 1; i <= 10; i++) {
  let multi = numero * i;
  console.log(numero + "x" + i + "=" + multi);
}
